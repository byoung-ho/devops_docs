"""
requirement_3.md 검증 템플릿 스크립트  (학생용)

이 파일은 무엇인가요?
--------------------
여러분(TE 역할)이 requirement_3 을 "직접 검증"하고, 그 결과를
Markdown Report 파일로 만드는 방법을 익히기 위한 '템플릿'입니다.

이미 동작하는 예제 몇 개가 들어 있습니다. 실행하면 바로 Report 가 생깁니다.
그다음, 아래 `TODO` 부분을 채워서 나머지 TE 시나리오를 완성하세요.

검증 대상 (requirement_3)
  - FE : badgeClass() 상태→색상(CSS class) 매핑
  - CI : .github/workflows/ci.yml (GitHub Actions)

────────────────────────────────────────────────────────────────────────
[알아두기] CI 시나리오(10~13)는 두 종류로 나뉩니다.
  · 파일/로컬로 확인 가능 : ci.yml 설정, health/API 로컬 재현 (11, 12)
  · 추가 정보가 필요      : 실제 GitHub Actions 실행(10), Render 배포(13)
  이 템플릿은 "로컬에서 확인 가능한 부분"까지 다룹니다.
  실제 실행/배포는 GitHub Actions 탭과 Render URL 에서 직접 눈으로 확인하세요.
────────────────────────────────────────────────────────────────────────

실행 방법
--------
    python tests/req3_test_template.py

결과
----
    tests/reports/req3_report_template.md
"""

import os
import re
import sys
import time
import json
import socket
import subprocess
import urllib.request
import urllib.error
from datetime import datetime

try:
    sys.stdout.reconfigure(encoding="utf-8")
except Exception:
    pass

# =============================================================================
# 경로 설정 (수정할 필요 없음)
# =============================================================================
THIS_DIR = os.path.dirname(os.path.abspath(__file__))
PROJECT_ROOT = os.path.dirname(THIS_DIR)
REPORT_DIR = os.path.join(THIS_DIR, "reports")
REPORT_PATH = os.path.join(REPORT_DIR, "req3_report_template.md")
APP_JS_PATH = os.path.join(PROJECT_ROOT, "app", "static", "app.js")
CI_YML_PATH = os.path.join(PROJECT_ROOT, ".github", "workflows", "ci.yml")

os.chdir(PROJECT_ROOT)
BASE_URL = None

results = []  # (TC ID, 시나리오, 기대결과, 실제결과, 통과여부)


def check(tc_id, scenario, expected, actual, passed):
    results.append((tc_id, scenario, expected, actual, passed))
    print(f"  [{'PASS' if passed else 'FAIL'}] {tc_id}  {scenario}")


# =============================================================================
# HTTP 유틸 (수정할 필요 없음)
# =============================================================================
def http_get(path, timeout=5):
    try:
        with urllib.request.urlopen(BASE_URL + path, timeout=timeout) as resp:
            return resp.status, None
    except urllib.error.HTTPError as e:
        return e.code, None
    except Exception:
        return None, None


# =============================================================================
# badgeClass 매핑 파서 (수정할 필요 없음)
#   app.js 의 badgeClass() 함수를 읽어 (상태 → CSS class) 딕셔너리로 만든다.
#   예)  badge_map["active"] == "status-active"
# =============================================================================
def parse_badge_map():
    if not os.path.exists(APP_JS_PATH):
        return {}
    code = open(APP_JS_PATH, encoding="utf-8").read()
    m = re.search(r"function\s+badgeClass\s*\([^)]*\)\s*\{", code)
    if not m:
        return {}
    start = m.end() - 1
    depth = 0
    i = start
    while i < len(code):
        if code[i] == "{":
            depth += 1
        elif code[i] == "}":
            depth -= 1
            if depth == 0:
                break
        i += 1
    body = code[start:i]
    mapping = {}
    for line in body.splitlines():
        if line.strip().startswith("//"):
            continue
        rm = re.search(r'return\s*"badge\s+status-([a-zA-Z]+)"', line)
        if not rm:
            continue
        cls = "status-" + rm.group(1).lower()
        for kw in re.findall(r'"([a-zA-Z]+)"', line.split("return")[0]):
            mapping[kw.lower()] = cls
    return mapping


# =============================================================================
# 서버 기동 유틸 (수정할 필요 없음)
# =============================================================================
def find_free_port():
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.bind(("127.0.0.1", 0))
    port = s.getsockname()[1]
    s.close()
    return port


def start_server(port):
    proc = subprocess.Popen(
        [sys.executable, "-m", "uvicorn", "app.main:app",
         "--host", "127.0.0.1", "--port", str(port)],
        cwd=PROJECT_ROOT, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
    )
    for _ in range(40):
        if proc.poll() is not None:
            return proc, False
        try:
            with urllib.request.urlopen(f"http://127.0.0.1:{port}/health", timeout=1) as r:
                if r.status == 200:
                    return proc, True
        except Exception:
            time.sleep(0.5)
    return proc, False


def stop_server(proc):
    if proc and proc.poll() is None:
        proc.terminate()
        try:
            proc.wait(timeout=5)
        except subprocess.TimeoutExpired:
            proc.kill()


# =============================================================================
# 검증 실행부  ★★★ 여기서부터 여러분이 채웁니다 ★★★
# =============================================================================
def run_tests():
    badge_map = parse_badge_map()   # {"active": "status-active", ...}

    # -------------------------------------------------------------------------
    # [예제 1] TE #1 : Active 상태 → 초록 badge (status-active)
    #   badge_map 에서 "active" 를 찾아 기대 class 와 비교합니다.
    # -------------------------------------------------------------------------
    passed = badge_map.get("active") == "status-active"
    check("TE-1", "Active 상태 구독자 확인", "초록 badge (status-active)",
          f'{badge_map.get("active")}', passed)

    # -------------------------------------------------------------------------
    # [예제 2] TE #5 : Offline 상태 → 회색 badge (status-offline)
    # -------------------------------------------------------------------------
    passed = badge_map.get("offline") == "status-offline"
    check("TE-5", "Offline 상태 가전 확인", "회색 badge (status-offline)",
          f'{badge_map.get("offline")}', passed)

    # -------------------------------------------------------------------------
    # [예제 3] CI 설정 : ci.yml 파일이 존재하는가?
    # -------------------------------------------------------------------------
    ci_exists = os.path.exists(CI_YML_PATH)
    check("CI-01", ".github/workflows/ci.yml 존재", "파일 존재",
          "존재" if ci_exists else "없음", ci_exists)

    # -------------------------------------------------------------------------
    # [예제 4] TE #11 : CI health 체크를 로컬에서 재현 (GET /health → 200)
    #   CI 가 하는 일과 동일한 명령을 로컬에서 실행해 봅니다.
    # -------------------------------------------------------------------------
    status, _ = http_get("/health")
    check("TE-11", "CI health 체크 (로컬 재현)", "200 OK",
          f"status={status}", status == 200)

    # =========================================================================
    # ★ TODO 1 : TE #
    # ...
    # ...
    # ...


# =============================================================================
# Markdown Report 생성 (수정할 필요 없음)
# =============================================================================
def render_report():
    total = len(results)
    passed = sum(1 for *_, p in results if p)
    failed = total - passed
    rate = (passed / total * 100) if total else 0.0

    lines = []
    lines.append("# requirement_3 검증 Report (TE 실습)")
    lines.append("")
    lines.append("| 항목 | 내용 |")
    lines.append("|------|------|")
    lines.append("| **프로젝트** | webOS Subscription Management Dashboard |")
    lines.append("| **검증 대상** | requirement_3.md (상태 Badge + GitHub Actions CI) |")
    lines.append(f"| **검증 일시** | {datetime.now().strftime('%Y-%m-%d %H:%M:%S')} |")
    lines.append("| **작성자** | (여기에 이름을 적으세요) |")
    lines.append("")
    lines.append(f"**총 {total}건 중 PASS {passed} / FAIL {failed} - Pass Rate {rate:.1f}%**")
    lines.append("")
    lines.append("| TC ID | 테스트 시나리오 | 기대 결과 | 실제 결과 | 판정 |")
    lines.append("|:-----:|----------------|-----------|-----------|:----:|")
    for tc_id, scenario, expected, actual, passed_ in results:
        mark = "✅ PASS" if passed_ else "❌ FAIL"
        lines.append(f"| {tc_id} | {scenario} | {expected} | {actual} | {mark} |")
    lines.append("")
    lines.append("> TE-10(실제 CI 실행), TE-13(Render 배포)은 GitHub Actions 탭과 배포 URL 에서 직접 확인하세요.")
    lines.append("> 본 Report 는 `tests/req3_test_template.py` 로 생성되었습니다.")

    os.makedirs(REPORT_DIR, exist_ok=True)
    with open(REPORT_PATH, "w", encoding="utf-8") as f:
        f.write("\n".join(lines) + "\n")
    return passed, failed, total, rate


# =============================================================================
# main (수정할 필요 없음)
# =============================================================================
def main():
    global BASE_URL
    print("=" * 60)
    print(" requirement_3 검증 (학생용 템플릿)")
    print("=" * 60)

    if PROJECT_ROOT not in sys.path:
        sys.path.insert(0, PROJECT_ROOT)

    port = find_free_port()
    print(f"[서버 기동] 127.0.0.1:{port} ...")
    proc, ok = start_server(port)
    if not ok:
        print("[오류] 서버 기동 실패. requirements 설치 및 app/main.py 를 확인하세요.")
        stop_server(proc)
        sys.exit(1)

    BASE_URL = f"http://127.0.0.1:{port}"
    print("[서버 기동] 성공\n")

    run_tests()

    stop_server(proc)

    passed, failed, total, rate = render_report()
    print("\n" + "=" * 60)
    print(f" 결과: PASS {passed} / FAIL {failed} (총 {total}) - {rate:.1f}%")
    print(f" Report 저장: {os.path.relpath(REPORT_PATH, PROJECT_ROOT)}")
    print("=" * 60)


if __name__ == "__main__":
    main()
