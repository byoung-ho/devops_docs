"""
requirement_2.md 검증 템플릿 스크립트  (학생용)

이 파일은 무엇인가요?
--------------------
여러분(TE 역할)이 requirement_2 를 "직접 검증"하고, 그 결과를
Markdown Report 파일로 만드는 방법을 익히기 위한 '템플릿'입니다.

이미 동작하는 예제 몇 개가 들어 있습니다. 실행하면 바로 Report 가 생깁니다.
그다음, 아래 `TODO` 부분을 채워서 나머지 TE 시나리오를 완성하세요.

검증 대상 (requirement_2)
  - BE: GET /api/subscribers/{userId}/devices  (가전 목록)
        GET /api/devices/{deviceId}/usage       (사용 현황)
  - FE: selectSubscriber / renderDevices / selectDevice / renderUsageChart

실행 방법
--------
    # 프로젝트 루트에서
    python tests/req2_test_template.py

결과
----
    tests/reports/req2_report_template.md   (여러분이 만든 검증 Report)

────────────────────────────────────────────────────────────────────────
검증 흐름 3단계 (requirement_2.md 기준)
  1) 개발자 테스트  : BE 함수가 값을 올바로 반환/예외 처리하는가?
  2) API 테스트     : 서버를 켜고 실제 엔드포인트가 동작하는가? (정상 / 404)
  3) TE 시나리오    : 가전 검색/필터가 "기대 결과"대로 동작하는가?
────────────────────────────────────────────────────────────────────────
"""

import os
import sys
import time
import json
import socket
import subprocess
import urllib.request
import urllib.error
from datetime import datetime

# Windows 콘솔(cp949)에서도 한글/기호가 깨지지 않도록 출력 인코딩을 UTF-8 로 설정
try:
    sys.stdout.reconfigure(encoding="utf-8")
except Exception:
    pass

# =============================================================================
# 경로 설정 (수정할 필요 없음)
# =============================================================================
THIS_DIR = os.path.dirname(os.path.abspath(__file__))
PROJECT_ROOT = os.path.dirname(THIS_DIR)
REPORT_DIR = os.path.join(THIS_DIR, "reports")
REPORT_PATH = os.path.join(REPORT_DIR, "req2_report_template.md")

os.chdir(PROJECT_ROOT)
BASE_URL = None

# 검증 결과를 담는 리스트. 각 항목: (TC ID, 시나리오, 기대결과, 실제결과, 통과여부)
results = []


def check(tc_id, scenario, expected, actual, passed):
    """검증 결과 1건을 기록한다."""
    results.append((tc_id, scenario, expected, actual, passed))
    tag = "PASS" if passed else "FAIL"
    print(f"  [{tag}] {tc_id}  {scenario}")


# =============================================================================
# HTTP 유틸 (수정할 필요 없음)
# =============================================================================
def http_get(path, timeout=5):
    """(status_code, json_data) 반환. 실패/에러 시 status 코드만이라도 반환."""
    try:
        with urllib.request.urlopen(BASE_URL + path, timeout=timeout) as resp:
            body = resp.read().decode("utf-8")
            try:
                return resp.status, json.loads(body)
            except json.JSONDecodeError:
                return resp.status, None
    except urllib.error.HTTPError as e:
        return e.code, None       # 예: 404
    except Exception:
        return None, None


# 가전 검색/필터 로직 (app.js renderDevices 와 동일한 규칙을 파이썬으로 재현)
def filter_devices(devices, search="", status=""):
    s = (search or "").lower()
    out = []
    for d in devices:
        matches_search = (
            s in d["type"].lower()
            or s in d["model"].lower()
            or s in d["status"].lower()
            or s in d["deviceId"].lower()
            or s in d["location"].lower()
        )
        matches_status = (not status) or d["status"] == status
        if matches_search and matches_status:
            out.append(d)
    return out


# =============================================================================
# 서버 기동 유틸 (수정할 필요 없음)
# =============================================================================
def find_free_port():
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.bind(("127.0.0.1", 0))
    port = s.getsockname()[1]
    s.close()
    return port


def start_server(port):
    proc = subprocess.Popen(
        [sys.executable, "-m", "uvicorn", "app.main:app",
         "--host", "127.0.0.1", "--port", str(port)],
        cwd=PROJECT_ROOT, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
    )
    for _ in range(40):
        if proc.poll() is not None:
            return proc, False
        try:
            with urllib.request.urlopen(f"http://127.0.0.1:{port}/health", timeout=1) as r:
                if r.status == 200:
                    return proc, True
        except Exception:
            time.sleep(0.5)
    return proc, False


def stop_server(proc):
    if proc and proc.poll() is None:
        proc.terminate()
        try:
            proc.wait(timeout=5)
        except subprocess.TimeoutExpired:
            proc.kill()


# =============================================================================
# 검증 실행부  ★★★ 여기서부터 여러분이 채웁니다 ★★★
# =============================================================================
def run_tests():
    # -------------------------------------------------------------------------
    # [예제 1] 개발자 테스트 : get_devices_by_user("U001") 가 2개를 반환하는가?
    #   서버 없이도 함수를 직접 불러서 확인할 수 있습니다.
    # -------------------------------------------------------------------------
    try:
        from app.api.subscribers import get_devices_by_user
        d = get_devices_by_user("U001")
        passed = isinstance(d, list) and len(d) == 2
        actual = f"{len(d)}개 반환" if isinstance(d, list) else "list 아님/None"
    except Exception as e:
        passed, actual = False, f"예외: {e}"
    check("DEV-01", "get_devices_by_user('U001') 직접 호출", "2개 가전 반환", actual, passed)

    # -------------------------------------------------------------------------
    # [예제 2] API 테스트 : GET /api/subscribers/U001/devices 가 200 인가?
    # -------------------------------------------------------------------------
    status, body = http_get("/api/subscribers/U001/devices")
    check("API-01", "GET /api/subscribers/U001/devices", "200 OK",
          f"status={status}", status == 200)

    # 이후 TE 시나리오에서 재사용할 U001 의 가전 목록
    u001_devices = body if isinstance(body, list) else []

    # -------------------------------------------------------------------------
    # [예제 3] TE 시나리오 #1 : U001 가전 목록 → 2개 (D001, D002)
    # -------------------------------------------------------------------------
    ids = [d["deviceId"] for d in u001_devices]
    passed = ids == ["D001", "D002"]
    check("TE-1", "/api/subscribers/U001/devices 호출", "D001, D002 (2개) 반환",
          f"{ids}", passed)

    # -------------------------------------------------------------------------
    # [예제 4] TE 시나리오 #3 : 미존재 사용자 U999 → 404
    #   http_get 은 404 일 때 status=404 를 반환합니다.
    # -------------------------------------------------------------------------
    status, _ = http_get("/api/subscribers/U999/devices")
    check("TE-3", "/api/subscribers/U999/devices 호출", "404 에러 반환",
          f"status={status}", status == 404)

    # -------------------------------------------------------------------------
    # [예제 5] TE 시나리오 #6 : 가전 검색 "TV" → TV 타입만 표시
    #   filter_devices() 로 검색 결과를 계산합니다.
    # -------------------------------------------------------------------------
    r = filter_devices(u001_devices, search="TV")
    passed = len(r) == 1 and r and r[0]["type"] == "TV"
    check("TE-6", '가전 검색 "TV" 입력', "TV 타입만 표시",
          f'{len(r)}개: {[d["deviceId"] for d in r]}', passed)

    # =========================================================================
    # ★ TODO 1 : TE 시나리오 #
    # ...
    # ...
    # ...


# =============================================================================
# Markdown Report 생성 (수정할 필요 없음)
# =============================================================================
def render_report():
    total = len(results)
    passed = sum(1 for *_, p in results if p)
    failed = total - passed
    rate = (passed / total * 100) if total else 0.0

    lines = []
    lines.append("# requirement_2 검증 Report (TE 실습)")
    lines.append("")
    lines.append("| 항목 | 내용 |")
    lines.append("|------|------|")
    lines.append("| **프로젝트** | webOS Subscription Management Dashboard |")
    lines.append("| **검증 대상** | requirement_2.md (가전 목록 + 사용 현황 + 차트) |")
    lines.append(f"| **검증 일시** | {datetime.now().strftime('%Y-%m-%d %H:%M:%S')} |")
    lines.append("| **작성자** | (여기에 이름을 적으세요) |")
    lines.append("")
    lines.append(f"**총 {total}건 중 PASS {passed} / FAIL {failed} - Pass Rate {rate:.1f}%**")
    lines.append("")
    lines.append("| TC ID | 테스트 시나리오 | 기대 결과 | 실제 결과 | 판정 |")
    lines.append("|:-----:|----------------|-----------|-----------|:----:|")
    for tc_id, scenario, expected, actual, passed_ in results:
        mark = "✅ PASS" if passed_ else "❌ FAIL"
        lines.append(f"| {tc_id} | {scenario} | {expected} | {actual} | {mark} |")
    lines.append("")
    lines.append("> 본 Report 는 `tests/req2_test_template.py` 로 생성되었습니다.")

    os.makedirs(REPORT_DIR, exist_ok=True)
    with open(REPORT_PATH, "w", encoding="utf-8") as f:
        f.write("\n".join(lines) + "\n")
    return passed, failed, total, rate


# =============================================================================
# main (수정할 필요 없음)
# =============================================================================
def main():
    global BASE_URL
    print("=" * 60)
    print(" requirement_2 검증 (학생용 템플릿)")
    print("=" * 60)

    if PROJECT_ROOT not in sys.path:
        sys.path.insert(0, PROJECT_ROOT)

    port = find_free_port()
    print(f"[서버 기동] 127.0.0.1:{port} ...")
    proc, ok = start_server(port)
    if not ok:
        print("[오류] 서버 기동 실패. requirements 설치 및 app/main.py 를 확인하세요.")
        stop_server(proc)
        sys.exit(1)

    BASE_URL = f"http://127.0.0.1:{port}"
    print("[서버 기동] 성공\n")

    run_tests()

    stop_server(proc)

    passed, failed, total, rate = render_report()
    print("\n" + "=" * 60)
    print(f" 결과: PASS {passed} / FAIL {failed} (총 {total}) - {rate:.1f}%")
    print(f" Report 저장: {os.path.relpath(REPORT_PATH, PROJECT_ROOT)}")
    print("=" * 60)


if __name__ == "__main__":
    main()
